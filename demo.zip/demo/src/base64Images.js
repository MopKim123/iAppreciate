export const GLOBAL_VARIABLE_1 = 'Value 1'; 
export const GLOBAL_VARIABLE_2 = 'Value 2';
