// import logo from './logo.svg';
import './App.css';
import React, { useState, useEffect } from 'react';
import emailjs from '@emailjs/browser';
import { GLOBAL_VARIABLE_1, GLOBAL_VARIABLE_2 } from './base64Images.js';
import png1 from './badges/1.png'
import png2 from './badges/2.png'
import png3 from './badges/3.png'
import png4 from './badges/4.png'
import png5 from './badges/5.png'
import png6 from './badges/6.png'
import png7 from './badges/7.png'
import png8 from './badges/8.png'
import png9 from './badges/9.png'
import png10 from './badges/10.png'
import png11 from './badges/11.png'
import png12 from './badges/12.png'
import png13 from './badges/13.png'
import png14 from './badges/14.png'
import png15 from './badges/15.png'
import png16 from './badges/16.png'
import png17 from './badges/17.png'
import png18 from './badges/18.png'
import png19 from './badges/19.png' 

function App() {
  
  // State variables to store form data
  const [senderName, setSenderName] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  const [receiverName, setReceiverName] = useState('');
  const [receiverEmail, setReceiverEmail] = useState('');
  const [selectedImage, setSelectedImage] = useState('');
  const [message, setMessage] = useState('');



  // Function to handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();


    const formData = {
      sender_name: senderName,
      sender_email: senderEmail,
      receiver_name: receiverName,
      receiver_email: receiverEmail,
      message: message,
      image: selectedImage,
      attachment: {
        name: 'test2.jpeg', // File name
        data: selectedImage, // Image data (Base64-encoded string)
        type: 'image/jpeg', // Image MIME type 
        cid: 'image1', // Content ID for referencing in email template
        encoded: true
      },
      // Add more fields as needed
    };


    emailjs.send('service_64t7o9j', 'template_wk5zble', formData, 'UapKvKlcMOVJTgbLy')
      .then((result) => {
        console.log('Email sent successfully:', result.text);
      }, (error) => {
        console.error('Email sending failed:', error.text);
      });
  };

  // Function to handle image selection
  const handleImageChange = (event) => {
    setSelectedImage(event.target.value);
  };

  return (
    <form onSubmit={handleSubmit} className="gradient-background">
      <div  className="form">
        <div  className="field"> {/* Sender name */}
          <label htmlFor="senderName" 
            className="label">Sender's Name: </label> 
          <input
            type="text"
            id="senderName"
            className="input"
            value={senderName}
            onChange={(event) => setSenderName(event.target.value)}
            required
          />
        </div>
        <div  className="field"> {/* Sender email */}
          <label htmlFor="senderEmail">Sender's Email: </label>
          <input
            type="email"
            id="senderEmail"
            className="input"
            value={senderEmail}
            onChange={(event) => setSenderEmail(event.target.value)}
            required
          />
        </div>
        <div  className="field"> {/* Employee name */}
          <label htmlFor="receiverName">Employee's Name: </label>
          <input
            type="text"
            id="receiverName"
            className="input"
            value={receiverName}
            onChange={(event) => setReceiverName(event.target.value)}
            required
          />
        </div>
        <div  className="field"> {/* Employee email */}
          <label htmlFor="receiverEmail">Employee's Email: </label>
          <input
            type="email"
            id="receiverEmail"
            className="input"
            value={receiverEmail}
            onChange={(event) => setReceiverEmail(event.target.value)}
            required
          />
        </div>
        <div className="field"> {/* Messages */}
          <label htmlFor="message">Message: </label>
          <input
            type="text"
            id="message"
            className="input"
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            required
          />
        </div>
        <div  className="field">
          <p>Select Image:</p>
          <div className='image-list'> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png1} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png2} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png3} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png4} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png5} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png6} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png7} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png8} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png9} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png10} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png11} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png12} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png13} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png14} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png15} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png16} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png17} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png18} alt="1.png" className='image' />
            </label> 
            <label>
              <input
                type="radio" 
                value="image1"
                checked={selectedImage === 'image1'}
                onChange={handleImageChange}
              />
              <img src={png19} alt="1.png" className='image' />
            </label> 
            {/* Add more images as needed */}
          </div> 
        </div>
        <button type="submit">Send Email</button>
      </div>
    </form>
  );
}

export default App;
